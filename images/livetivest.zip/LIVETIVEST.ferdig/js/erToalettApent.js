function erToalettApent() {};

//Lager variabler for nåtid
let idagRaatekst = new Date();
let dag = idagRaatekst.getDay();
let natidTimer = idagRaatekst.getHours();
let natidMinutter = idagRaatekst.getMinutes();

//Funksjon som sjekker om gitt toalett er åpent nå eller ved et annet gitt klokkeslett - i ukedagene
function ukedagToalettApent(toalett) {
    if (!toalett.tid_hverdag || toalett.tid_hverdag == "NULL") {
        return false
    }
    if (toalett.tid_hverdag == "ALL") {
        return true
    }

    let ukedagApningstiderRaa = toalett.tid_hverdag.split('-')[0].split(".");
    let ukedagApningTimer = parseInt(ukedagApningstiderRaa[0]);
    let ukedagApningMinutter = parseInt(ukedagApningstiderRaa[1]);

    let ukedagStengetiderRaa = toalett.tid_hverdag.split('-')[1].split(".");
    let ukedagStengingTimer = parseInt(ukedagStengetiderRaa[0]);
    let ukedagStengingMinutter = parseInt(ukedagStengetiderRaa[1]);

    if (natidTimer < ukedagApningTimer || natidTimer > ukedagStengingTimer) {
        return false
    } else if (natidTimer == ukedagApningTimer && natidMinutter <= ukedagApningMinutter) {
        return false
    } else if (natidTimer == ukedagStengingTimer && natidMinutter >= ukedagStengingMinutter) {
        return false
    }
    return true
}

//Funksjon som sjekker om gitt toalett er åpent nå eller ved et annet gitt klokkeslett - på lørdager
function lordagToalettApent(toalett) {
    if (!toalett.tid_lordag || toalett.tid_lordag == "NULL") {
        return false
    }
    if (toalett.tid_lordag == "ALL") {
        return true
    }

    let ukedagApningstiderRaa = toalett.tid_lordag.split('-')[0].split(".");
    let ukedagApningTimer = parseInt(lordagApningstiderRaa[0]);
    let ukedagApningMinutter = parseInt(lordagApningstiderRaa[1]);

    let lordagStengetiderRaa = toalett.tid_lordag.split('-')[1].split(".");
    let lordagStengingTimer = parseInt(lordagStengetiderRaa[0]);
    let lordagStengingMinutter = parseInt(lordagStengetiderRaa[1]);

    if (natidTimer < ukedagApningTimer || natidTimer > lordagStengingTimer) {
        return false
    } else if (natidTimer == ukedagApningTimer && natidMinutter <= lordagStengingTimer) {
        return false
    } else if (natidTimer == lordagStengingTimer && natidMinutter >= lordagStengingMinutter) {
        return false
    }
    return true
}

//Funksjon som sjekker om gitt toalett er åpent nå eller ved et annet gitt klokkeslett - på søndager
function sondagToalettApent(toalett) {
    if (!toalett.tid_sondag || toalett.tid_sondag == "NULL") {
        return false
    }
    if (toalett.tid_sondag == "ALL") {
        return true
    }

    let sondagApningstiderRaa = toalett.tid_hverdag.split('-')[0].split(".");
    let sondagApningTimer = parseInt(sondagApningstiderRaa[0]);
    let ukedagApningMinutter = parseInt(sondagApningstiderRaa[1]);

    let sondagStengetiderRaa = toalett.tid_hverdag.split('-')[1].split(".");
    let sondagStengingTimer = parseInt(sondagStengetiderRaa[0]);
    let sondagStengingMinutter = parseInt(sondagStengetiderRaa[1]);

    if (natidTimer < sondagApningTimer || natidTimer > sondagStengingTimer) {
        return false
    } else if (natidTimer == sondagApningTimer && natidMinutter <= ukedagApningMinutter) {
        return false
    } else if (natidTimer == sondagStengingTimer && natidMinutter >= sondagStengingMinutter) {
        return false
    }
    return true
}


function lordagToalettApent(toalett) {
    if (!toalett.tid_lordag || toalett.tid_lordag == "NULL") {
        return false
    }
    if (toalett.tid_lordag == "ALL") {
        return true
    }

    let ukedagApningstiderRaa = toalett.tid_lordag.split('-')[0].split(".");
    let ukedagApningTimer = parseInt(lordagApningstiderRaa[0]);
    let ukedagApningMinutter = parseInt(lordagApningstiderRaa[1]);

    let lordagStengetiderRaa = toalett.tid_lordag.split('-')[1].split(".");
    let lordagStengingTimer = parseInt(lordagStengetiderRaa[0]);
    let lordagStengingMinutter = parseInt(lordagStengetiderRaa[1]);

    if (natidTimer < ukedagApningTimer || natidTimer > lordagStengingTimer) {
        return false
    } else if (natidTimer == ukedagApningTimer && natidMinutter <= lordagStengingTimer) {
        return false
    } else if (natidTimer == lordagStengingTimer && natidMinutter >= lordagStengingMinutter) {
        return false
    }
    return true
}

function sondagToalettApent(toalett) {
    if (!toalett.tid_sondag || toalett.tid_sondag == "NULL") {
        return false
    }
    if (toalett.tid_sondag == "ALL") {
        return true
    }

    let sondagApningstiderRaa = toalett.tid_hverdag.split('-')[0].split(".");
    let sondagApningTimer = parseInt(sondagApningstiderRaa[0]);
    let ukedagApningMinutter = parseInt(sondagApningstiderRaa[1]);

    let sondagStengetiderRaa = toalett.tid_hverdag.split('-')[1].split(".");
    let sondagStengingTimer = parseInt(sondagStengetiderRaa[0]);
    let sondagStengingMinutter = parseInt(sondagStengetiderRaa[1]);

    if (natidTimer < sondagApningTimer || natidTimer > sondagStengingTimer) {
        return false
    } else if (natidTimer == sondagApningTimer && natidMinutter <= ukedagApningMinutter) {
        return false
    } else if (natidTimer == sondagStengingTimer && natidMinutter >= sondagStengingMinutter) {
        return false
    }
    return true
}
