//Lage et sokeKriterier objekt
var sokeKriterier = {}

function avansertsok() {
    var resultatet = [];

    //Sjekker om brukeren har huket av for mann eller dame og gir sokekravobjektet en attributt med resultatet
    var kvinne = document.getElementById("dame");
    var mann = document.getElementById("herre");

    if (kvinne.checked) {
        sokeKriterier.kvinne = "1"
    } else if (mann.checked) {
        sokeKriterier.mann = "1"
    }

    //Sjekker om brukeren har huket av for rullestoltilgang, og gir sokekravobjektet en attributt med resultatet
    var rullestoltilgangJa = document.getElementById("rulleJa");
    var rullestoltilgangNei = document.getElementById("rulleNei");

    if (rullestoltilgangJa.checked) {
        sokeKriterier.rullestoltilgang = "1"
    } else if (rullestoltilgangNei.checked) {
        sokeKriterier.rullestoltilgang = "NULL"
    }

    //Sjekker hvilken dag det er i dag, og gir sokekravobjektet en attributt med resultatet
    switch (dag) {
        case 0:
            sokeKriterier.dag = "Søndag";
            break;
        case 6:
            sokeKriterier.dag = "Lørdag";
            break;
        default:
            sokeKriterier.dag = "Ukedag";
    }

    //Sjekker om brukeren har huket av for stellerom, og gir sokekravobjektet en attributt med resultatet
    let stelleromJa = document.getElementById("stelleromJa");
    let stelleromNei = document.getElementById("stelleromNei");

    if (stelleromJa.checked) {
        sokeKriterier.stellerom = "1"
    } else if (stelleromNei.checked) {
        sokeKriterier.stellerom = "NULL"
    }

    //Sjekker hvilken makspris brukeren eventuelt har valgt, og gir sokekravobjektet en attributt med resultatet
    let minPris = document.getElementById("5");
    let mediumPris = document.getElementById("10");
    let maksPris = document.getElementById("20");
    let gratis = document.getElementById("gratis");

    if (minPris.checked) {
        sokeKriterier.pris = "5"
    } else if (mediumPris.checked) {
        sokeKriterier.pris = "10"
    } else if (maksPris.checked) {
        sokeKriterier.pris = "20"
    }
    //Sjekker om brukeren har huket av for gratis, og gir sokekravobjektet en attributt med resultatet
    if (gratis.checked) {
        sokeKriterier.pris = "0"
    }

    //Sjekker om brukeren har skrevet inn klokkeslett og gir sokekravobjektet en attributt med resultatet, i tillegg til å lage variabler for timer og minutter
    let brukerValgtTidRaaformat = document.getElementById("klokkeslett").value;
    if (brukerValgtTidRaaformat) {
        sokeKriterier.brukerValgtTid = brukerValgtTidRaaformat;
        let brukerValgtTid = sokeKriterier.brukerValgtTid.split(":");
        let timer = parseInt(brukerValgtTid[0]);
        let minutter = parseInt(brukerValgtTid[1]);
        natidTimer = timer;
        natidMinutter = minutter;
    }

    //Sjekker hvilke variabler fra datasettet som oppfyller kravene fra sokekrav-objektet, og legger de til i resultat-listen.
    toaletter.forEach(function(x) {
        if (sokeKriterier.kvinne && x.dame !== sokeKriterier.kvinne) {
            return
        }
        if (sokeKriterier.mann && x.herre !== sokeKriterier.mann) {
            return
        }
        if (sokeKriterier.rullestoltilgang && x.rullestol !== sokeKriterier.rullestoltilgang) {
            return
        }
        if (sokeKriterier.stellerom && x.stellerom !== sokeKriterier.stellerom) {
            return
        }

        //Pris
        let toalettPris = parseInt(x.pris);
        if (sokeKriterier.pris && toalettPris > 0 && toalettPris > sokeKriterier.pris) {
            return
        }

        let apent = document.getElementById("apent");
        if ((apent && apent.checked) || sokeKriterier.brukerValgtTid) {
            if (sokeKriterier.dag == "Ukedag" && !ukedagToalettApent(x)) {
                return
            } else if (sokeKriterier.dag == "Lørdag" && !lordagToalettApent(x)) {
                return
            } else if (sokeKriterier.dag == "Søndag" && !sondagToalettApent(x)) {
                return
            }
        }
        resultatet.push(x)
    })

    //Oppdaterer kart og liste med resultatene
    initMap(resultatet);
    lagListe(resultatet);
}
