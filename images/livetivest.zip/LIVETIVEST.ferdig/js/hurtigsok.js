function hurtigsok(samling) {

    //Henter ut brukerinput via html-koden og lagrer det som en tekstverdi i en variabel.
    var tekstverdi = document.getElementById("tekstfelt").value.toString().toLowerCase();

    //RegEx-uttrykk som tillater
    var krav = /\w+[^?&=+-@d]/gi;

    //Sjekker om brukerinputen består regex-kravet
    let tekstResultat = krav.test(tekstverdi);
    if (!tekstResultat) {
        return
    }


    //Lager en testvariabel som sjekker om brukerinputen matcher med filtreringsordet.
    //Ved match gjengir den ønsket informasjon i en ny variabel.
    let navnTest = tekstverdi.match(/navn:(\w+)/gi);
    let navn = navnTest ? navnTest.toString().split(":")[1] : null;

    let adresseTest = tekstverdi.match(/adresse:(\w+)/gi);
    let adresse = adresseTest ? adresseTest.toString().split(":")[1] : null;

    let kjonnTest = tekstverdi.match(/kjonn:(\w+)/gi);
    let kjonn = kjonnTest ? kjonnTest.toString().split(":")[1] : null;

    let rullestolTest = tekstverdi.match(/rullestol/gi);
    let rullestol = rullestolTest ? rullestolTest : null;

    let stelleromTest = tekstverdi.match(/stellerom/gi);
    let stellerom = stelleromTest ? stelleromTest : null;

    let apentNaTest = tekstverdi.match(/åpent nå|| apent naa/gi);
    let apentNa = apentNaTest ? apentNaTest : null;

    let klokkeslettTest = tekstverdi.match(/kl:(\w+)(.)(\w+)/gi);
    let klokkeslett = klokkeslettTest ? klokkeslettTest.toString().split(":")[1].split(".") : null;

    let maksPrisTest = tekstverdi.match(/makspris:(\w+)/gi);
    let maksPrisRaw = maksPrisTest ? maksPrisTest.toString().split(":")[1] : null;
    let makspris = parseInt(maksPrisRaw);

    let gratisTest = tekstverdi.match(/gratis/gi);
    let gratis = gratisTest ? gratisTest : null;

    //Lage et sokekrav-objekt
    let sokeKrav = {
        navn,
        adresse,
        kjonn,
        rullestol,
        stellerom,
        apentNa,
        klokkeslett,
        makspris,
        gratis,
    };


    //Filtrerer ut hvilke av toaletter som oppfyller kravene sokekrav-objektet, og legger til i resultat-listen.
    let resultater = samling.filter(x => {
        if (sokeKrav.navn && !x.plassering.toLowerCase().includes(sokeKrav.navn)) {
          return false;
        }

        if (sokeKrav.adresse && !x.adresse.toLowerCase().includes(sokeKrav.adresse)) {
            return false;
        }


        if (sokeKrav.kjonn) {
            if (sokeKrav.kjonn === "dame" && x.dame !== "1") {
                return false;
            } else if (sokeKrav.kjonn === "herre" && x.herre !== "1") {
                return false;
            }
        }

        if (sokeKrav.rullestol && x.rullestol !== "1") {
            return false;
        }

        if (sokeKrav.stellerom && x.stellerom !== "1") {
            return false;
        }
        if (sokeKrav.apentNa) {
            //natidTimer = idagRaatekst.getHours();
            //natidMinutter = idagRaatekst.getMinutes();
        if (sokeKrav.apentNa && dag > 0 && dag < 6 && !ukedagToalettApent(x)) {
            return false;
        } else if (sokeKrav.apentNa && dag == 0 && !sondagToalettApent(x)) {
            return false;
        } else if (sokeKrav.apentNa && dag == 6 && !lordagToalettApent(x)) {
            return false;
        }
      }

        if (sokeKrav.klokkeslett) {
            natidTimer = parseInt(klokkeslett[0]);
            natidMinutter = parseInt(klokkeslett[1]);
            if (dag > 0 && dag < 6 && !ukedagToalettApent(x)) {
                return false;
            } else if (sokeKrav.klokkeslett && dag == 0 && !sondagToalettApent(x)) {
                return false;
            } else if (sokeKrav.klokkeslett && dag == 6 && !lordagToalettApent(x)) {
                return false;
            }
        }

        if (sokeKrav.gratis && x.pris !== "0" && x.pris !== "NULL") {
           return false;
        }

        if (sokeKrav.makspris && sokeKrav.makspris < x.pris) {
            return false;
        }

        return true;
    })

    //Oppdaterer kart og liste med resultatene
    initMap(resultater);
    lagListe(resultater);
}
