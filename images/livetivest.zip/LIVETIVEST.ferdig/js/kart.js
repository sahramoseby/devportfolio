var samling = [];
var toaletter = [];
var lekeplasser = [];
var toaletterStavanger = [];
var promise;

//funksjon som henter ut JSONkode
function hentData(url) {
    return new Promise(function(resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    resolve(samling = JSON.parse(xhr.responseText).entries);
                } else {
                    reject(xhr.statusText);
                }
            };
        }
        xhr.send();
    });
}
//Funksjon som laster ned datasettet lekeplasser i Bergen og lager en generert liste
function lastNedLekeplasser() {
    var url = "https://hotell.difi.no/api/json/bergen/lekeplasser";

    hentData(url).then(function(response) {
        lekeplasser = response;
        lagListe(lekeplasser);
        console.log("det er lekeplasser i Bergen");
    }).catch(function(reason) {
        console.log("FEIL: " + reason);
    });
}

//Funksjon som laster ned datasettet toaletter fra Bergen og lager en generert liste
function lastNedToaletter() {
    var url = "https://hotell.difi.no/api/json/bergen/dokart";

    hentData(url).then(function(response) {
        toaletter = response;
        lagListe(toaletter);
        console.log("det er toaletter i Bergen");
    }).catch(function(reason) {
        console.log("FEIL: " + reason);
    });
}

//Funksjon som laster ned datasettet toaletter fra Stavanger og lager en generert liste
function lastNedStavanger() {
    var url = "https://hotell.difi.no/api/json/stavanger/offentligetoalett?";

    hentData(url).then(function(response) {
        toaletterStavanger = response;
        lagListe(toaletterStavanger);
        console.log("Det er toaletter i Stavanger");
    }).catch(function(reason) {
        console.log("FEIL: " + reason);
    });
}

function visLekeplasser() {
    lastNedLekeplasser();
}

function visToaletter() {
    lastNedToaletter();
    sok();
    erToalettApent();
}

function visStavanger() {
    lastNedStavanger();
}


function visFavoritToaletter() {
    lastNedLekeplasser();
    setTimeout(lastNedToaletter, 100); //setter en timeOut slik at lagListe() blir kalt på toaletter først
    setTimeout(velgFavoritt, 300); //lager en select/option-funksjon for å velge FavoritToalett etter datasettet er nedlastet
    setTimeout(finnNaermest, 500); //Finner nærmest etter de andre funksjonene er lastet ned
}


//Skal finne den nærmeste lekeplassen til brukerens valgte favorittToalett
function finnNaermest() {
    //Sjekker om alternativet brukeren har valgt eksisterer i toalettlisten,
    //Hvis den eksisterer i toalettlisten, blir den til variabelen fra toalettlisten
    let valgtToalett;
    const valgtToalettPlassering = document.getElementById("velgToalett").value;
    for (let x = 0; x < toaletter.length; x++) {
        if (toaletter[x].plassering == valgtToalettPlassering) {
            valgtToalett = toaletter[x];
        }
    }

    let lekeplass;
    let minAvstand = 100;

    for (let i = 0; i < lekeplasser.length; i++) {
        let avstand = finnAvstand(valgtToalett, lekeplasser[i]);
        if (!lekeplass || avstand < minAvstand) {
          minAvstand = avstand
          lekeplass = lekeplasser[i];
        };
    }
    const valgtToalettOgLekeplass = [valgtToalett, lekeplass];
    initMap(valgtToalettOgLekeplass);
    lagListe(valgtToalettOgLekeplass);

    let objekt = document.getElementById("info");
    while (objekt.firstChild) {
      objekt.removeChild(objekt.firstChild);
    }
    var infoTekst = document.getElementById("info");
    var i;
    i = document.createTextNode(lekeplass.navn + " er den nærmeste lekeplassen til ditt favorittoalett: " + valgtToalett.plassering);
    infoTekst.appendChild(i);
}

//Lager en dropdown-liste, hvor man kan velge et toalett
function velgFavoritt() {
    var valg = document.getElementById("velgToalett");
    var option;
    for (var i = 0; i < toaletter.length; i++) {
          var a = toaletter[i].plassering;
          option = document.createElement("option");
          option.value = a;
          option.text = a;
          valg.add(option);
    }
}
//Finner avstanden mellom to objekter
function finnAvstand(p1, p2) {
    var aLat = ((p1.latitude) - (p2.latitude));
    var aLong = ((p1.longitude) - (p2.longitude));
    var avstand = Math.sqrt((aLat * aLat) + (aLong * aLong));
    return avstand;
}

//Håndterer hurtig- og avansertsøket på html-siden, slik at man kan veksle mellom søkene ved å trykke på en knapp
function sok() {
    const advancedSearch = document.querySelector(".avansertsok");
    const quickSearch = document.querySelector(".hurtigsok");
    const quickSearchInput = document.querySelector(".hurtigsok-input");
    const searchToggleButton = document.querySelector(".sokefelt");

    searchToggleButton.addEventListener("click", e => {
        e.preventDefault();

        advancedSearch.classList.toggle("skjult");
        quickSearch.classList.toggle("skjult");

        if (quickSearch.classList.contains("skjult")) {
            searchToggleButton.innerText = 'Skjul avansert søk';
        } else {
            searchToggleButton.innerText = 'Vis avansert søk';
        }
    });
    quickSearchInput.addEventListener("keyup", e => {
        if (e.key.toLowerCase() === "enter") {
            e.preventDefault();
            hurtigsok();
        }
    });
}

//Genererer en nummerert liste basert på et parametergitt datasett
function lagListe(data) {
    let objekt = document.getElementById("listeObjekt"); //Lager et objekt av listen fra html-siden
    //Dersom det allerede eksisterer et listeobjekt fjernes den, og oppdaterer med den nye listen
    while (objekt.firstChild) {
      objekt.removeChild(objekt.firstChild);
    }
    for (let i = 0; i < data.length; i++) { //Itererer over konvertert JSON-kode
        let li = document.createElement("li"); //Lager en liste-tag
        var t;

        if(data[i].plassering && data[i].plassering !== "," && data[i].plassering !== "") {
            t = document.createTextNode(data[i].plassering);
        } else if (data[i].navn && data[i].navn !== "") {
            t = document.createTextNode(data[i].navn);
        } else { continue }

        li.appendChild(t);
        objekt.appendChild(li);
    }
    initMap(data);
}


//Henter ut kordinater og lager et google maps basert på en parametergitt samling
function initMap(param) {
    var datasett = param;
    if (datasett === undefined) {
        datasett = samling;
    }

    var bounds = new google.maps.LatLngBounds();
    var kart = new google.maps.Map(document.getElementById("kart"), {
    });
    var marker = {};

         for (var i = 0; i < datasett.length; i++) {
           if(datasett[i].latitude){
              marker =  new google.maps.Marker({
                 position: new google.maps.LatLng(Number(datasett[i].latitude),Number(datasett[i].longitude)),
                 map: kart,
                 label: (i+1).toString()
              }
            );}

        bounds.extend(marker.position);
    }
    kart.fitBounds(bounds);
}
