function ikkeTrivieltSok() {

    //Lager en tom liste som til slutt skal inneholde resultatene etter søket
    var resultat = [];

    //Lage et sokekrav-objekt
    var sokekrav = {}

    //Sjekker om brukeren har huket av for rullestoltilgang og gir sokekravobjektet en attributt med resultatet
    var rullestoltilgangJa = document.getElementById("rulleJa");
    var rullestoltilgangNei = document.getElementById("rulleNei");

    if (rullestoltilgangJa.checked) {
        sokekrav.rullestoltilgang = "JA"
    } else if (rullestoltilgangNei.checked) {
        sokekrav.rullestoltilgang = "NEI"
    }

    //Sjekker om brukeren har huket av for stellerom og gir sokekravobjektet en attributt med resultatet
    var stelleromJa = document.getElementById("stelleromJa");
    var stelleromNei = document.getElementById("stelleromNei");

    if (stelleromJa.checked) {
        sokekrav.stellerom = "JA"
    } else if (stelleromNei.checked) {
        sokekrav.stellerom = "NEI"
    }

    //Sjekker hvilke av toalettene i Stavanger som oppfyller kravene fra sokekrav-objektet, og legger til i resultat-listen.
    toaletterStavanger.forEach(function(x) {
        if (sokekrav.rullestoltilgang && x.rullestol !== sokekrav.rullestoltilgang) {
            return
        }
        if (sokekrav.stellerom && x.stellerom !== sokekrav.stellerom) {
            return
        }
        resultat.push(x)

    })
    //Oppdaterer kart og liste med resultatene
    initMap(resultat);
    lagListe(resultat);
}
